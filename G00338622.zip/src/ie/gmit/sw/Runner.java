package ie.gmit.sw;

public class Runner {
	
	public static void main(String[] args) 
	{
		Menu m1 = new Menu();
		
		m1.runMenu();
		
	}//End main//
}

